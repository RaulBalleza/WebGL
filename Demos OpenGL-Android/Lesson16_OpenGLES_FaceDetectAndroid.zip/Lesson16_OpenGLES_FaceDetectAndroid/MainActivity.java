package com.example.androidfacedetectionapi;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.Camera;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseArray;
import android.view.Surface;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.vision.Frame;
import com.google.android.gms.vision.face.Face;
import com.google.android.gms.vision.face.FaceDetector;

import java.io.InputStream;

//public class MainActivity extends AppCompatActivity {
public class MainActivity extends Activity implements Camera.PictureCallback {

    private static final int REQUEST_PERMISSION_CAMERA = 100;
    CameraSurfaceView cameraSurfaceView;
    Button shutterButton;
    Button saveFrameBufferButton;
    //static Context CX = this.getApplicationContext();


    private GLSurfaceView mGLView;
    //private CubeRenderer mRenderer;
    FrameLayout preview;

    private int getRotacion (int rotation)
    {
        int angle;
        switch (rotation) {
            case Surface.ROTATION_90:
                angle = -90;
                break;
            case Surface.ROTATION_180:
                angle = 180;
                break;
            case Surface.ROTATION_270:
                angle = 90;
                break;
            default:
                angle = 0;
                break;
        }
        return angle;
    }

    private void askPermissionOnly() {
        this.askPermission(REQUEST_PERMISSION_CAMERA, Manifest.permission.CAMERA);
    }

    // With Android Level >= 23, you have to ask the user
    // for permission with device (For example read/write data on the device).
    private boolean askPermission(int requestId, String permissionName) {
        if (android.os.Build.VERSION.SDK_INT >= 23) {

            // Check if we have permission
            int permission = ActivityCompat.checkSelfPermission(this, permissionName);


            if (permission != PackageManager.PERMISSION_GRANTED) {
                // If don't have permission so prompt the user.
                this.requestPermissions(
                        new String[]{permissionName},
                        requestId
                );
                return false;
            }
        }
        return true;
    }

    // When you have the request results
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        //
        // Note: If request is cancelled, the result arrays are empty.
        if (grantResults.length > 0) {
            switch (requestCode) {
                case REQUEST_PERMISSION_CAMERA:
                    if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                        //cargarControles();
                        Toast.makeText(getApplicationContext(), "Permission Lectura Concedido!", Toast.LENGTH_SHORT).show();
                        //cargarControles();
                    }
                    break;
                /*case REQUEST_ID_WRITE_PERMISSION:
                    if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                        //writeFile();
                        //
                        Toast.makeText(getApplicationContext(), "Permission Escritura Concedido!", Toast.LENGTH_SHORT).show();
                        //cargarControles();
                    }
                    break; */
                default:
                    break;

            }
        } else {
            Toast.makeText(getApplicationContext(), "Permission Cancelled!", Toast.LENGTH_SHORT).show();
        }
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        askPermissionOnly();


        setContentView(R.layout.activity_main);

        //this.requestWindowFeature()


        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
/*
        int rotation =  getWindowManager().getDefaultDisplay().getRotation();
        TextView TV1 = findViewById(R.id.TV_info);
        TV1.setText("Angulo : "+ getRotacion(rotation));

        // set up our preview surface
        preview = (FrameLayout) findViewById(R.id.camera_preview);
        cameraSurfaceView = new CameraSurfaceView(this);
        preview.addView(cameraSurfaceView);
        // grab out shutter button so we can reference it later
        shutterButton = (Button) findViewById(R.id.shutter_button);
        shutterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                takePicture();
            }
        });
*/


        InputStream stream = getResources().openRawResource(R.raw.image01);
        Bitmap bitmap = BitmapFactory.decodeStream(stream);

        FaceDetector detector = new FaceDetector.Builder(getApplicationContext())
                .setTrackingEnabled(false)
                .setLandmarkType(FaceDetector.ALL_LANDMARKS)
                .setClassificationType(FaceDetector.ALL_CLASSIFICATIONS)
                .build();

        // Create a frame from the bitmap and run face detection on the frame.
        Frame frame = new Frame.Builder().setBitmap(bitmap).build();
        SparseArray<Face> faces = detector.detect(frame);

        CustomView overlay = (CustomView) findViewById(R.id.customView);
        overlay.setContent(bitmap, faces);

        detector.release();
    }

    @Override
    public void onPictureTaken(byte[] bytes, Camera camera) {

        Log.i("X", "Saving a bitmap to file");
        Bitmap picture = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
        //shutterButton.setEnabled(false);
        //cameraSurfaceView.takePicture(this);
        //camera.startPreview();
    }

    private void takePicture() {
        shutterButton.setEnabled(false);
        cameraSurfaceView.takePicture(this);
    }
}

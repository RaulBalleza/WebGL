##### OpenCV: QR Code detection and extraction
QR Code detection and extraction using OpenCV [click here](http://dsynflo.blogspot.in/2014/10/opencv-qr-code-detection-and-extraction.html)
##### Instructions
```bash
git clone https://github.com/bharathp666/opencv_qr.git
cd opencv_qr
# Antes borrar los archivos CMakeCache.txt y la carpeta CMakeFiles
cmake .
make
./qr_video
```

